+ PageResponse
+ File này để làm gì?

Nó là model chuẩn để trả dữ liệu phân trang.

Ví dụ response sẽ ra kiểu:

{
"success": true,
"message": "User list fetched successfully",
"data": {
"content": [
{
"id": 1,
"fullName": "Nguyen Van A",
"email": "a@gmail.com",
"phone": "0987",
"active": true
}
],
"page": 0,
"size": 5,
"totalElements": 12,
"totalPages": 3,
"last": false
}
}
Vì sao không trả thẳng Page<UserResponse>?

Vẫn làm được, nhưng chưa đẹp bằng.

Lý do:
Page là object framework của Spring
response sẽ lộ cấu trúc không hoàn toàn theo ý mình
khó giữ format ổn định lâu dài
Dùng PageResponse lợi hơn:
chủ động thiết kế format API
frontend dễ dùng hơn
sau này đổi framework vẫn giữ response ổn định

Đây là tư duy rất tốt.