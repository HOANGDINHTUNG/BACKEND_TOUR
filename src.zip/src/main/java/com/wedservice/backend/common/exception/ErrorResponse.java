package com.wedservice.backend.common.exception;

/*
Ý nghĩa

Khi API lỗi, mình sẽ trả về thống nhất kiểu:

{
  "success": false,
  "message": "Validation failed",
  "errorCode": "VALIDATION_ERROR",
  "timestamp": "2026-03-27T10:00:00",
  "errors": {
    "email": "Email is invalid"
  }
}
*/

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Map;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class ErrorResponse {
    private boolean success;
    private String message;
    private String errorCode;
    private LocalDateTime timestamp;
    private Map<String, String> errors;
}
