package com.wedservice.backend.common.response;
/*
Ý nghĩa

Thay vì trả lung tung mỗi API một kiểu, sau này mình sẽ thống nhất dạng:

{
  "success": true,
  "message": "Success",
  "data": ...
}
*/
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class ApiResponse<T> {
    private boolean success;
    private String message;
    private T data;
}

