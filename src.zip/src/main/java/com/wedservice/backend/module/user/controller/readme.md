Vì sao không để trong controller?

Vì controller nên mỏng.

Controller chỉ nên:

nhận request
gọi service
trả response

Nếu nhét nghiệp vụ vào controller, sau này rất rối và khó test.

Điểm chưa hoàn hảo nhưng chấp nhận ở bước này

Hiện tại password đang lưu thẳng DB.

Điều này chưa chuẩn production.

Nhưng tôi cố tình để tạm ở bước này để bạn hiểu flow trước. Ở bước sau về auth/security, mình sẽ thêm:

PasswordEncoder
mã hóa password bằng BCrypt

Senior thật sự sẽ mã hóa password, nhưng học theo lớp như vậy sẽ chắc hơn.

-------------------------------------------------------------------------------------

+ UserController
  File này dùng để làm gì?

Đây là lớp nhận HTTP request từ frontend/Postman.

API này sẽ là:

POST /api/v1/users

Do bạn đã có context path /api/v1.

Giải thích các annotation
@RestController

Biến class thành REST API controller.

@RequestMapping("/users")

Base path cho module user.

@PostMapping

API POST để tạo dữ liệu.

@Valid

Bật validation cho CreateUserRequest.

Nếu dữ liệu sai, Spring sẽ tự ném MethodArgumentNotValidException, và GlobalExceptionHandler sẽ xử lý.

----------------------------------------

Controller chỉ:

nhận request
gọi service
bọc response

Không để query DB hoặc business logic ở đây.

Đây là cách làm sạch và dễ test hơn.