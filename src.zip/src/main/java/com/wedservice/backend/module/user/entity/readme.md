File này dùng để làm gì?

User.java là entity. Nó đại diện cho một bảng trong database.

Tức là class này sẽ map với bảng:

users

Mỗi object User tương ứng với một dòng dữ liệu trong bảng.

Giải thích từng annotation
@Entity

Báo với JPA rằng đây là entity để quản lý.

@Table(name = "users")

Chỉ định tên bảng là users.

Senior hay ghi rõ @Table để:

tránh tên bảng bị generate mơ hồ
dễ kiểm soát DB
dễ đọc schema
@Id

Khóa chính.

@GeneratedValue(strategy = GenerationType.IDENTITY)

ID tự tăng trong MySQL.

@Column(nullable = false, unique = true, ...)

Ràng buộc ở mức DB.

Ví dụ:

nullable = false: không cho null
unique = true: email không được trùng
Vì sao tốt hơn cách bình thường?

Người mới đôi khi chỉ viết field trống trơn, không ràng buộc gì trong DB.

Ví dụ:

private String email;

Cách đó yếu vì:

DB không bảo vệ dữ liệu
dễ bị email trùng
lỗi phát hiện muộn

Còn cách mình làm:

validation ở app
ràng buộc ở DB
an toàn hơn 2 lớp

Đây là tư duy tốt.