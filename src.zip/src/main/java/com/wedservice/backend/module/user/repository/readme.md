+ UserRepository

File này dùng để làm gì?

Repository là lớp giao tiếp với database.

Bạn không cần tự viết SQL cho các thao tác cơ bản như:

insert
update
delete
find by id
find all

vì JpaRepository đã hỗ trợ sẵn.

Vì sao thêm existsByEmail và findByEmail?
existsByEmail

Dùng để check email đã tồn tại chưa trước khi tạo user.

findByEmail

Sau này dùng cho login hoặc lấy user theo email.

Vì sao cách này tốt?

Người mới hay để logic query lung tung trong service hoặc controller.
Senior thường gom truy cập dữ liệu vào repository cho sạch tầng.

--------------------------------

Ý nghĩa từng method mới
findByFullNameContainingIgnoreCaseAndActive(...)

Tìm theo tên có chứa keyword và lọc theo active.

Ví dụ:

keyword = nguyen
active = true

thì lấy user có tên chứa “nguyen” và đang active.

findByFullNameContainingIgnoreCase(...)

Chỉ tìm theo tên, không lọc active.

findByActive(...)

Chỉ lọc active/inactive.

Vì sao dùng query method của Spring Data JPA?

Đây là điểm rất hay của Spring Data:

Bạn viết tên method đúng quy tắc, nó tự sinh query.

Lợi ích:
nhanh
sạch
không cần viết SQL sớm
Khi nào chưa đủ?

Khi query phức tạp hơn, lúc đó mới qua:

@Query
Specification
QueryDSL

Hiện tại mình chọn cách này vì:

đủ tốt
dễ học
vẫn rất chuẩn cho bước đầu