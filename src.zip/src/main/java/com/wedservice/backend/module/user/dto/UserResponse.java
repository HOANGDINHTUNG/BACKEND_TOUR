package com.wedservice.backend.module.user.dto;

import com.wedservice.backend.module.user.entity.Role;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserResponse {
    private Long id;
    private String fullName;
    private String email;
    private String phone;
    private Boolean active;
    private Role role;
}
